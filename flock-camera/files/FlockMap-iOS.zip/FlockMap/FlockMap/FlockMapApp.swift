import SwiftUI

@main
struct FlockMapApp: App {
    @State private var store = CameraStore()
    @State private var location = LocationManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(store)
                .environment(location)
                .task { await store.loadCachedThenRefreshIfStale() }
        }
    }
}
