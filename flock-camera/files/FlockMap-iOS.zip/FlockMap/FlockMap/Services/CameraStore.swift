import Foundation
import Observation
import CoreLocation

/// Owns the camera dataset, on-disk cache, and filter state.
@Observable
final class CameraStore {
    var cameras: [Camera] = []
    var generatedAt: Date?
    var bbox: BBox = .denverMetro
    var isLoading = false
    var errorMessage: String?

    // Filters
    var flockOnly = false
    var operatorFilter: String? = nil
    var searchText = ""

    private let service = OverpassService()
    private let cacheURL: URL = {
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        return dir.appendingPathComponent("cameras.json")
    }()

    var operators: [String] {
        Array(Set(cameras.compactMap(\.operatorName))).sorted()
    }

    var filtered: [Camera] {
        let q = searchText.trimmingCharacters(in: .whitespaces).lowercased()
        return cameras.filter { c in
            if flockOnly && !c.isFlock { return false }
            if let op = operatorFilter, c.operatorName != op { return false }
            if !q.isEmpty, !c.tags.contains(where: { $0.key.lowercased().contains(q) || $0.value.lowercased().contains(q) }) { return false }
            return true
        }
    }

    var flockCount: Int { filtered.filter(\.isFlock).count }

    func nearest(to loc: CLLocation, limit: Int = 5) -> [(Camera, CLLocationDistance)] {
        filtered.map { ($0, $0.location.distance(from: loc)) }
            .sorted { $0.1 < $1.1 }
            .prefix(limit).map { $0 }
    }

    // MARK: - Loading

    @MainActor
    func loadCachedThenRefreshIfStale(maxAge: TimeInterval = 24 * 3600) async {
        loadCache()
        let stale = generatedAt.map { Date().timeIntervalSince($0) > maxAge } ?? true
        if cameras.isEmpty || stale { await refresh() }
    }

    @MainActor
    func refresh() async {
        guard !isLoading else { return }
        isLoading = true; errorMessage = nil
        defer { isLoading = false }
        do {
            let fetched = try await service.fetch(bbox: bbox)
            cameras = fetched
            generatedAt = Date()
            saveCache()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func loadCache() {
        guard let data = try? Data(contentsOf: cacheURL),
              let snap = try? JSONDecoder().decode(CameraSnapshot.self, from: data) else { return }
        cameras = snap.cameras; generatedAt = snap.generatedAt; bbox = snap.bbox
    }

    private func saveCache() {
        guard let gen = generatedAt else { return }
        let snap = CameraSnapshot(generatedAt: gen, bbox: bbox, cameras: cameras)
        try? JSONEncoder().encode(snap).write(to: cacheURL, options: .atomic)
    }
}
