import SwiftUI

struct FilterView: View {
    @Environment(CameraStore.self) private var store
    @Environment(LocationManager.self) private var location
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        @Bindable var store = store
        @Bindable var location = location
        NavigationStack {
            Form {
                Section("Cameras") {
                    Toggle("Flock Safety only", isOn: $store.flockOnly)
                    Picker("Operator", selection: $store.operatorFilter) {
                        Text("Any").tag(String?.none)
                        ForEach(store.operators, id: \.self) { Text($0).tag(String?.some($0)) }
                    }
                    TextField("Search tags (e.g. Aurora, Genetec)", text: $store.searchText)
                        .textInputAutocapitalization(.never)
                }
                Section {
                    Toggle("Alert me near a camera", isOn: $location.alertsEnabled)
                    if location.alertsEnabled {
                        Stepper("Within \(Int(location.alertRadius)) m", value: $location.alertRadius, in: 100...1000, step: 50)
                    }
                } header: { Text("Proximity alerts") } footer: {
                    Text(location.authorization == .denied
                         ? "Location access is off. Enable it in Settings to use alerts."
                         : "Alerts fire while the app is open. Add the Location updates background mode in Xcode to get them while driving with the app closed.")
                }
                Section {
                    Button("Clear filters") { store.flockOnly = false; store.operatorFilter = nil; store.searchText = "" }
                }
            }
            .navigationTitle("Filter")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Done") { dismiss() } }
        }
    }
}
