import Foundation

enum OverpassError: LocalizedError {
    case badStatus(Int)
    var errorDescription: String? {
        switch self {
        case .badStatus(let c):
            return c == 429 || c == 504
                ? "OpenStreetMap's Overpass API is busy (HTTP \(c)). Wait a minute and try again."
                : "Overpass returned HTTP \(c)."
        }
    }
}

/// Queries the Overpass API for ALPR / Flock surveillance nodes inside a bbox.
struct OverpassService {
    var endpoint = URL(string: "https://overpass-api.de/api/interpreter")!

    private struct Response: Decodable {
        struct Element: Decodable { let id: Int; let lat: Double; let lon: Double; let tags: [String: String]? }
        let elements: [Element]
    }

    func query(for bbox: BBox) -> String {
        let bb = bbox.overpass
        return """
        [out:json][timeout:180];
        (
          node["man_made"="surveillance"]["surveillance:type"="ALPR"](\(bb));
          node["man_made"="surveillance"]["manufacturer"~"[Ff]lock"](\(bb));
          node["man_made"="surveillance"]["brand"~"[Ff]lock"](\(bb));
        );
        out body;
        """
    }

    func fetch(bbox: BBox) async throws -> [Camera] {
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.timeoutInterval = 200
        req.setValue("FlockMap-iOS/1.0 (personal ALPR map)", forHTTPHeaderField: "User-Agent")
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        var cs = CharacterSet.urlQueryAllowed; cs.remove(charactersIn: "&+=")
        req.httpBody = "data=\(query(for: bbox).addingPercentEncoding(withAllowedCharacters: cs)!)".data(using: .utf8)

        let (data, resp) = try await URLSession.shared.data(for: req)
        if let http = resp as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            throw OverpassError.badStatus(http.statusCode)
        }
        let decoded = try JSONDecoder().decode(Response.self, from: data)
        return decoded.elements
            .map { Camera(id: $0.id, lat: $0.lat, lon: $0.lon, tags: $0.tags ?? [:]) }
            .sorted { $0.id < $1.id }
    }
}
