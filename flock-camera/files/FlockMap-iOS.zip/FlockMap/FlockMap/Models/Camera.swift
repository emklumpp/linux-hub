import Foundation
import CoreLocation

/// One ALPR camera node from OpenStreetMap. Mirrors the JSON the Rust fetcher writes,
/// but the app builds these straight from Overpass so it needs no server.
struct Camera: Identifiable, Codable, Hashable {
    let id: Int
    let lat: Double
    let lon: Double
    let tags: [String: String]

    var coordinate: CLLocationCoordinate2D { .init(latitude: lat, longitude: lon) }
    var location: CLLocation { .init(latitude: lat, longitude: lon) }

    var manufacturer: String? { tags["manufacturer"] ?? tags["brand"] }
    var operatorName: String? { tags["operator"] }
    var surveillanceType: String? { tags["surveillance:type"] }
    var direction: Double? { tags["camera:direction"].flatMap(Double.init) }
    var isFlock: Bool { manufacturer?.lowercased().contains("flock") ?? false }
    var osmURL: URL { URL(string: "https://www.openstreetmap.org/node/\(id)")! }

    static func == (a: Camera, b: Camera) -> Bool { a.id == b.id }
    func hash(into h: inout Hasher) { h.combine(id) }
}

/// Bounding box: south, west, north, east
struct BBox: Codable, Equatable {
    var south: Double, west: Double, north: Double, east: Double
    static let denverMetro = BBox(south: 39.45, west: -105.35, north: 40.15, east: -104.55)
    var overpass: String { "\(south),\(west),\(north),\(east)" }
}

struct CameraSnapshot: Codable {
    var generatedAt: Date
    var bbox: BBox
    var cameras: [Camera]
}
