import SwiftUI
import MapKit

struct NearbyView: View {
    @Environment(CameraStore.self) private var store
    @Environment(LocationManager.self) private var location
    @Environment(\.dismiss) private var dismiss
    var select: (Camera) -> Void

    var body: some View {
        NavigationStack {
            Group {
                if let loc = location.current {
                    List(store.nearest(to: loc, limit: 25), id: \.0.id) { cam, dist in
                        Button {
                            dismiss(); select(cam)
                        } label: {
                            HStack {
                                CameraPin(camera: cam)
                                VStack(alignment: .leading) {
                                    Text(cam.manufacturer ?? "ALPR").font(.body)
                                    if let op = cam.operatorName { Text(op).font(.caption).foregroundStyle(.secondary) }
                                }
                                Spacer()
                                Text(MKDistanceFormatter().string(fromDistance: dist)).foregroundStyle(.secondary)
                            }
                        }.tint(.primary)
                    }
                } else {
                    ContentUnavailableView {
                        Label("Location needed", systemImage: "location.slash")
                    } description: {
                        Text("Allow location access to see the cameras closest to you.")
                    } actions: {
                        Button("Allow location") { location.requestPermission(); location.start() }
                    }
                }
            }
            .navigationTitle("Nearest cameras")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Done") { dismiss() } }
            .onAppear { if location.current == nil { location.start() } }
        }
    }
}
