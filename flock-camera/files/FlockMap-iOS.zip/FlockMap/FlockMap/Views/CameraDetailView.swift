import SwiftUI
import MapKit

struct CameraDetailView: View {
    let camera: Camera
    @Environment(LocationManager.self) private var location
    @Environment(\.openURL) private var openURL

    var body: some View {
        NavigationStack {
            List {
                Section {
                    row("Vendor", camera.manufacturer ?? "Unknown")
                    if let op = camera.operatorName { row("Operator", op) }
                    if let d = camera.direction { row("Faces", "\(Int(d))° \(compass(d))") }
                    if let t = camera.surveillanceType { row("Type", t) }
                    if let loc = location.current {
                        row("Distance", MKDistanceFormatter().string(fromDistance: camera.location.distance(from: loc)))
                    }
                    row("Coordinates", String(format: "%.5f, %.5f", camera.lat, camera.lon))
                }
                Section("All OpenStreetMap tags") {
                    ForEach(camera.tags.sorted(by: { $0.key < $1.key }), id: \.key) { k, v in
                        row(k, v)
                    }
                }
                Section {
                    Button("Open in Apple Maps") {
                        let item = MKMapItem(placemark: MKPlacemark(coordinate: camera.coordinate))
                        item.name = "\(camera.manufacturer ?? "ALPR") camera"
                        item.openInMaps()
                    }
                    Button("View / edit on OpenStreetMap") { openURL(camera.osmURL) }
                }
            }
            .navigationTitle(camera.isFlock ? "Flock Safety camera" : "License plate reader")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func row(_ k: String, _ v: String) -> some View {
        HStack(alignment: .top) {
            Text(k).foregroundStyle(.secondary)
            Spacer()
            Text(v).multilineTextAlignment(.trailing).textSelection(.enabled)
        }.font(.subheadline)
    }

    private func compass(_ deg: Double) -> String {
        let dirs = ["N","NE","E","SE","S","SW","W","NW"]
        return dirs[Int((deg + 22.5).truncatingRemainder(dividingBy: 360) / 45)]
    }
}
